#' mouse_kidney_203_Seurat
#'
#' A Seurat object containing mouse 203 kidney cells.
#' @source \url{https://www.ncbi.nlm.nih.gov/pubmed/?term=29089413}
"mouse_kidney_203_Seurat"
